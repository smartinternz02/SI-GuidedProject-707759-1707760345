
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String



def static "curaHealthcare.custofunctions_CuraHealthcare.CheckDropDownListElementExist"(
    	TestObject object	
     , 	String option	) {
    (new curaHealthcare.custofunctions_CuraHealthcare()).CheckDropDownListElementExist(
        	object
         , 	option)
}
