<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>CuraHealthcareTestSuiteManualMode</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>6b87680b-e644-4e3e-82a9-30c9cabbdf7d</testSuiteGuid>
   <testCaseLink>
      <guid>d0cdbfaf-b177-4c85-b13d-cd0bf15f6fd0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Modes/02Manual Mode/TC001_ManualMode_Cura</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>61390a7d-423e-4590-8214-3626651fbd1b</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
